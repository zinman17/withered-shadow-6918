# WallOfBricks for Cloudflare Workers

The whole site is JavaScript now. Same pages, same look, same rules, plus multiplayer in every place and a hardened server side. The movement engine is a rigid body simulation running the physics.js module: the character is a convex hull body on Rapier WebAssembly with walk 16, jump 50, gravity 196.2, stair climbing, coyote time and buffered jumps. Auth is 100 percent server side: the signup and login forms post straight to the Worker, passwords are hashed with PBKDF2 SHA-256 100000 iterations, sessions live in the D1 database with HttpOnly SameSite=Lax cookies and every form carries a per session CSRF token. No browser code touches a password ever.

## What you need

A Cloudflare account and a free GitHub account. The free Cloudflare plan is enough. Everything runs on Workers plus one D1 database on Cloudflare machines. No npm runtime dependencies.

## Deploy with clicks only (no wrangler, no self hosting)

Wrangler is only an uploader that pushes code to Cloudflare. The site never runs on your computer either way, and the dashboard can upload for you, so you never need the command line.

1. Unzip this project
2. On GitHub make a new empty repository and use Add file then Upload files, drag in everything the zip had (README, wrangler.jsonc, schema.sql, package.json, dev-server.js, the src folder and the public folder) and commit
3. In dash.cloudflare.com open Storage and Databases, D1, Create database, name it wob, open it and copy the Database ID
4. Back on GitHub open wrangler.jsonc, replace REPLACE_WITH_YOUR_D1_ID with the id you copied and commit
5. In the Cloudflare dashboard go to Workers and Pages, Create, Workers, Connect to Git, pick your repository, leave the settings alone and hit Deploy. Cloudflare builds and hosts it on their own machines
6. In the dashboard open the wob database, Console tab, paste everything from schema.sql and Run so the tables exist
7. Open the address Workers and Pages shows you, like https://wallofbricks.yourname.workers.dev and sign up

The site is live on Cloudflare worldwide. Turn your computer off, it stays up. Every later change is the same loop: edit a file on GitHub, Cloudflare redeploys by itself. You can attach a real domain later in Workers and Pages, your project, Settings, Domains and Routes.

## Optional command line deploy

The command line does the identical thing if you ever want it: `npm install`, then `npx wrangler login`, `npx wrangler d1 create wob` and paste the id into wrangler.jsonc, `npx wrangler d1 execute wob --remote --file=./schema.sql`, `npx wrangler deploy`.

## Local preview (optional)

`npm run dev` starts a preview on `http://127.0.0.1:8788` using the built in Node SQLite store in `data/wob.db`. This is only a preview on your machine, the real site stays on Cloudflare. Delete `data/wob.db` to reset.

## Multiplayer

Every place is a room. Logged in players send position updates 4 times a second and get everyone else back in the same request. Others show up as brick figures with name tags, positions are smoothed client side. Chat sits bottom left, up to 120 characters, one message per 750 ms, everything sanitized server side. Positions are clamped and rate gated per user in SQL so a hacked client cannot spam or teleport beyond the clamps.

## Security notes

- SQL injection: every query is a prepared statement, nothing is ever concatenated
- XSS: one escape function used everywhere, strict Content-Security-Policy with no inline script and no inline style anywhere. The play page additionally allows eval for the Lua VM and wasm compilation for the physics engine, the rest of the site stays locked to self
- CSRF: hidden token in every form and a header on every JSON call, checked in constant time, SameSite Lax cookies as a second wall
- Sessions: 256 bit random tokens, only the SHA-256 of the token is stored, rotated on login and logout, 7 day expiry, expired rows deleted on access
- Passwords: PBKDF2 SHA-256 with 100000 iterations and a 16 byte salt, constant time compare, a dummy hash is derived for unknown usernames so timing cannot reveal who exists
- Brute force: 5 login attempts per 15 minutes per username and IP, 3 signups per day per IP
- Uploads: extension whitelist, magic byte checks, real image dimension parsing for jpg png webp, glb header check, obj null byte check, 1.5 MB cap per file because uploads live in D1
- IDOR: every studio save, download, cloth image and edit checks ownership in the query
- Headers: CSP, frame deny, nosniff, referrer policy, permissions policy, HSTS on https
- Clothing textures stay private: they are served per user through an authenticated route, never public

## Notes

- Old `.php` links still work, the Worker serves them at the clean addresses too
- The catalog is hidden from the tab strip but the pages still work, the same as the PHP site
- Studio scripts are capped at 100000 characters and 100 scripts per place, objects at 400, exactly like before
